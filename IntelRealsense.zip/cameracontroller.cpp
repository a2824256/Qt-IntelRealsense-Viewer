#include "cameracontroller.h"
#include "cameraworker.h"
CameraController::CameraController()
{
    CameraWorker *worker = new CameraWorker;
    worker->moveToThread(&workerThread);
}

CameraController::~CameraController()
{

}

void CameraController::handleResults(const QString &result)
{

}
