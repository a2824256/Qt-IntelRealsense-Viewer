#ifndef CAMERAWORKER_H
#define CAMERAWORKER_H
#include <QObject>
#include <librealsense2/rs.hpp>
#include <opencv2/opencv.hpp>

class CameraWorker : public QObject
{
    Q_OBJECT
public:
    CameraWorker();
    ~CameraWorker();
public slots:
    void doWork(const QString &parameter);

signals:
    void resultReady(const QString &result);
};

#endif // CAMERAWORKER_H
