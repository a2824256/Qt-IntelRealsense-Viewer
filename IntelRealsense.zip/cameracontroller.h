#ifndef CAMERACONTROLLER_H
#define CAMERACONTROLLER_H
#include<QObject>
#include<QThread>
#include <librealsense2/rs.hpp>
#include <opencv2/opencv.hpp>

class CameraController : public QObject
{
    Q_OBJECT
    QThread workerThread;
public:
    CameraController();
    ~CameraController();
public slots:
    void handleResults(const QString &result);
signals:
    void operate(const QString &op);
};


#endif // CAMERACONTROLLER_H
