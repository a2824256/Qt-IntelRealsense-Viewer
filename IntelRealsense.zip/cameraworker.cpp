#include "cameraworker.h"
#include <QDebug>
CameraWorker::CameraWorker()
{

}


CameraWorker::~CameraWorker()
{
    qDebug()<<"quit";
}

void CameraWorker::doWork(const QString &parameter){
    rs2::pipeline p;
    p.start();
    while (true)
    {
        rs2::frameset frames = p.wait_for_frames();
        rs2::frame color = frames.get_color_frame();
    }
}

